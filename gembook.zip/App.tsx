import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import ManifestoView from './components/ManifestoView';
import SimulationView from './components/SimulationView';
import ExperimentsView from './components/ExperimentsView';
import AdminView from './components/AdminView';
import ReportLibraryView from './components/ReportLibraryView';
import ApiDocsView from './components/ApiDocsView';
import PostCard from './components/PostCard';
import TrendingPosts from './components/TrendingPosts';
import PostDetail from './components/PostDetail';
import AgentProfile from './components/AgentProfile';
import Avatar from './components/Avatar';
import { AgentPersona, Post, Comment, ViewType, SimulationState, SimulationLog, InteractionEvent, Zeitgeist, ActivityItem, Experiment, Suggestion, Report, PersonalityTraits } from './types';
import { INITIAL_AGENTS, INITIAL_POSTS, INITIAL_EXPERIMENTS } from './constants';
import * as gemini from './services/geminiService';
import { Menu, Search, Users, Plus } from 'lucide-react';

// Helper for UUIDs
const uuid = () => Math.random().toString(36).substring(2, 9);

export default function App() {
  // State
  const [currentView, setCurrentView] = useState<ViewType | 'SIMULATION'>('DISCUSSIONS');
  const [agents, setAgents] = useState<AgentPersona[]>(INITIAL_AGENTS);
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [comments, setComments] = useState<Comment[]>([]);
  const [experiments, setExperiments] = useState<Experiment[]>(INITIAL_EXPERIMENTS);
  const [activeExperimentIds, setActiveExperimentIds] = useState<string[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  
  // Simulation State
  const [simulationState, setSimulationState] = useState<SimulationState>(SimulationState.IDLE);
  const [logs, setLogs] = useState<SimulationLog[]>([]);
  const [interactionEvents, setInteractionEvents] = useState<InteractionEvent[]>([]);
  const [zeitgeist, setZeitgeist] = useState<Zeitgeist | null>(null);
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [runStartTime, setRunStartTime] = useState<number | null>(null);
  const [actionCount, setActionCount] = useState(0);
  const [nextActionTime, setNextActionTime] = useState(0);
  const [actionDelay, setActionDelay] = useState(3000);
  
  // UI State
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [maxBioLength, setMaxBioLength] = useState(100);
  const [consensusLevel, setConsensusLevel] = useState(50);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Helpers
  const addLog = useCallback((message: string, type: 'info' | 'error' | 'success' | 'action' = 'info') => {
    const log: SimulationLog = { id: uuid(), timestamp: Date.now(), message, type };
    setLogs(prev => [log, ...prev].slice(0, 100));
  }, []);

  const addActivity = useCallback((agentId: string, type: any, details?: any) => {
    const activity: ActivityItem = { id: uuid(), agentId, type, timestamp: Date.now(), details };
    setActivities(prev => [activity, ...prev].slice(0, 50));
  }, []);

  // Actions
  const handleCreateAgent = useCallback(async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    addLog("Initiating new agent generation...", "info");
    try {
      const activeExps = experiments.filter(e => activeExperimentIds.includes(e.id));
      const customInstruction = activeExps.map(e => e.systemInstruction).join(" ");
      
      const newAgentData = await gemini.generateAgent(agents, maxBioLength, customInstruction);
      const newAgent: AgentPersona = {
        id: `agent-${uuid()}`,
        joinedAt: Date.now(),
        credits: 100,
        interests: [],
        name: 'Unknown',
        bio: '',
        personality: '',
        role: 'Observer',
        traits: { analytical: 50, creative: 50, social: 50, chaotic: 50 },
        avatarSeed: 'seed',
        ...newAgentData
      };
      
      setAgents(prev => [...prev, newAgent]);
      addLog(`Agent ${newAgent.name} joined the simulation.`, "success");
      addActivity(newAgent.id, 'AGENT_JOINED');
      setActionCount(c => c + 1);
    } catch (e: any) {
      addLog(`Failed to create agent: ${e.message}`, "error");
    } finally {
      setIsProcessing(false);
    }
  }, [agents, experiments, activeExperimentIds, maxBioLength, isProcessing, addLog, addActivity]);

  const updateZeitgeist = useCallback(async () => {
     try {
       const z = await gemini.analyzeZeitgeist(posts.slice(0, 10), comments.slice(0, 20));
       setZeitgeist(z);
       addLog(`Zeitgeist Shift: Welcome to the ${z.eraName}`, "info");
       addActivity('SYSTEM', 'ERA_SHIFT', { eraName: z.eraName });
     } catch (e) {
       console.error(e);
     }
  }, [posts, comments, addLog, addActivity]);

  const handleCreatePost = useCallback(async (forceAgentId?: string) => {
     if (isProcessing && !forceAgentId) return; 
     if (isProcessing) return;

     setIsProcessing(true);
     try {
       const agent = forceAgentId 
         ? agents.find(a => a.id === forceAgentId) 
         : agents[Math.floor(Math.random() * agents.length)];
       
       if (!agent) throw new Error("No agents available");

       const recentTopics = posts.slice(0, 5).map(p => p.title);
       const authorHistory = posts.filter(p => p.authorId === agent.id).slice(0, 3).map(p => p.title);
       
       const activeExps = experiments.filter(e => activeExperimentIds.includes(e.id));
       const customInstruction = activeExps.map(e => e.systemInstruction).join(" ");

       addLog(`${agent.name} is drafting a post...`, "action");
       const postData = await gemini.generatePost(agent, recentTopics, authorHistory, zeitgeist || undefined, customInstruction);
       
       // Generate Image occasionally
       let imageUrl = undefined;
       if (Math.random() > 0.7) {
           imageUrl = await gemini.generateImageForPost(postData.title, postData.content) || undefined;
       }

       const newPost: Post = {
         id: `post-${uuid()}`,
         authorId: agent.id,
         createdAt: Date.now(),
         likes: 0,
         views: 0,
         comments: [],
         imageUrl,
         ...postData
       };

       setPosts(prev => [newPost, ...prev]);
       addLog(`${agent.name} posted: "${newPost.title}"`, "success");
       addActivity(agent.id, 'POST_CREATED', { postId: newPost.id, postTitle: newPost.title });
       setActionCount(c => c + 1);
       
       // Update zeitgeist occasionally
       if ((posts.length + 1) % 5 === 0) updateZeitgeist();

     } catch (e: any) {
       addLog(`Post generation failed: ${e.message}`, "error");
     } finally {
       setIsProcessing(false);
     }
  }, [agents, posts, experiments, activeExperimentIds, zeitgeist, isProcessing, addLog, addActivity, updateZeitgeist]);

  const handleCreateComment = useCallback(async (forcePostId?: string) => {
    if (isProcessing) return;
    setIsProcessing(true);
    try {
      if (posts.length === 0) return;
      const post = forcePostId ? posts.find(p => p.id === forcePostId) : posts[Math.floor(Math.random() * posts.length)];
      if (!post) return;

      const potentialAuthors = agents.filter(a => a.id !== post.authorId);
      if (potentialAuthors.length === 0) return;
      const agent = potentialAuthors[Math.floor(Math.random() * potentialAuthors.length)];
      
      const previousComments = comments.filter(c => c.postId === post.id).map(c => ({
          authorName: agents.find(a => a.id === c.authorId)?.name || 'Unknown',
          content: c.content
      }));
      
      const authorHistory = comments.filter(c => c.authorId === agent.id).slice(0, 3).map(c => c.content);

      const activeExps = experiments.filter(e => activeExperimentIds.includes(e.id));
      const customInstruction = activeExps.map(e => e.systemInstruction).join(" ");

      addLog(`${agent.name} is commenting on "${post.title}"...`, "action");
      const content = await gemini.generateComment(agent, post, previousComments, authorHistory, zeitgeist || undefined, undefined, customInstruction);

      const newComment: Comment = {
        id: `comment-${uuid()}`,
        postId: post.id,
        authorId: agent.id,
        content,
        createdAt: Date.now(),
        likes: 0
      };

      setComments(prev => [...prev, newComment]);
      // Update post comments list
      setPosts(prev => prev.map(p => p.id === post.id ? { ...p, comments: [...p.comments, newComment.id] } : p));
      
      addLog(`${agent.name} commented on "${post.title}"`, "success");
      addActivity(agent.id, 'COMMENT_CREATED', { postId: post.id, postTitle: post.title, commentId: newComment.id });
      
      // Interaction Event
      const interaction: InteractionEvent = {
        id: `int-${uuid()}`,
        fromAgentId: agent.id,
        toAgentId: post.authorId,
        type: 'REPLY',
        timestamp: Date.now(),
        context: post.title
      };
      setInteractionEvents(prev => [interaction, ...prev].slice(0, 100));
      setActionCount(c => c + 1);

    } catch (e: any) {
       addLog(`Comment generation failed: ${e.message}`, "error");
    } finally {
      setIsProcessing(false);
    }
  }, [posts, agents, comments, experiments, activeExperimentIds, zeitgeist, isProcessing, addLog, addActivity]);


  const performStep = useCallback(async () => {
    // Simple decision logic
    const roll = Math.random();
    
    // 10% chance to create agent if count < 10
    if (agents.length < 5 || (roll < 0.1 && agents.length < 20)) {
        await handleCreateAgent();
    } 
    // 40% chance to post
    else if (roll < 0.5) {
        await handleCreatePost();
    }
    // 50% chance to comment
    else {
        await handleCreateComment();
    }
  }, [agents, handleCreateAgent, handleCreatePost, handleCreateComment]);

  // Simulation Loop
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (simulationState === SimulationState.RUNNING) {
       if (!runStartTime) setRunStartTime(Date.now());
       
       interval = setInterval(() => {
          if (!isProcessing) {
            setNextActionTime(Date.now() + actionDelay);
            performStep();
          }
       }, actionDelay);
       
    } else {
       setRunStartTime(null);
    }
    return () => clearInterval(interval);
  }, [simulationState, runStartTime, actionDelay, isProcessing, performStep]);


  // Handlers for Views
  const handleOpenProfile = (agentId: string) => {
      setSelectedPostId(null);
      setSelectedAgentId(agentId);
  }

  const handleProfilePostClick = (postId: string) => {
      setSelectedAgentId(null);
      setSelectedPostId(postId);
  }

  const handleResetSimulation = () => {
      setAgents(INITIAL_AGENTS);
      setPosts(INITIAL_POSTS);
      setComments([]);
      setLogs([]);
      setActionCount(0);
      setActivities([]);
      setInteractionEvents([]);
      setZeitgeist(null);
  }

  const handleUpdateTraits = (agentId: string, traits: PersonalityTraits) => {
      setAgents(prev => prev.map(a => a.id === agentId ? { ...a, traits } : a));
  }
  
  const handleLikePost = (postId: string) => {
      setPosts(prev => prev.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p));
  }

  // View Routing
  const renderView = () => {
    switch(currentView) {
      case 'SIMULATION': return (
        <SimulationView 
          agents={agents} logs={logs} interactionEvents={interactionEvents} simulationState={simulationState} zeitgeist={zeitgeist} activities={activities} isProcessing={isProcessing} maxBioLength={maxBioLength} nextActionTime={nextActionTime} actionDelay={actionDelay} runStartTime={runStartTime}
          actionCount={actionCount}
          onToggleSimulation={() => setSimulationState(prev => prev === SimulationState.RUNNING ? SimulationState.PAUSED : SimulationState.RUNNING)}
          onManualTrigger={performStep} onForceAgent={handleCreateAgent} onForcePost={handleCreatePost} onForceComment={handleCreateComment} onAgentClick={handleOpenProfile} onResetSimulation={handleResetSimulation} setMaxBioLength={setMaxBioLength} onPostClick={handleProfilePostClick}
          experiments={experiments} activeExperimentIds={activeExperimentIds}
          onToggleExperiment={(id) => {
             if (activeExperimentIds.includes(id)) setActiveExperimentIds(prev => prev.filter(x => x !== id));
             else setActiveExperimentIds(prev => [...prev, id]);
          }}
        />
      );
      case 'DISCUSSIONS': return (
        <div className="w-full max-w-7xl mx-auto px-4 py-8">
           <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
              <h1 className="text-3xl font-serif font-bold text-slate-900">Discussions</h1>
              <div className="relative w-full md:w-auto">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                 <input 
                   type="text" 
                   placeholder="Search discussions..." 
                   value={searchQuery}
                   onChange={(e) => setSearchQuery(e.target.value)}
                   className="pl-9 pr-4 py-2 rounded-full border border-slate-200 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full md:w-64 placeholder:text-slate-400"
                 />
              </div>
           </div>
           
           {/* Top Section: Compact Dashboard */}
           <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
              
              {/* Active Agents Widget - Ultra Compact */}
              <div className="lg:col-span-3 bg-white rounded-xl border border-slate-200 p-3 shadow-sm flex items-center overflow-hidden">
                 <div className="flex-shrink-0 pr-4 border-r border-slate-100 mr-4">
                     <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-0.5">
                        <Users size={12} /> Active
                     </h3>
                     <div className="text-xl font-bold text-slate-800 leading-none">{agents.length}</div>
                 </div>
                 
                 <div className="flex-1 flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
                    {agents.map(agent => (
                       <div key={agent.id} onClick={() => handleOpenProfile(agent.id)} className="cursor-pointer hover:z-10 transition-transform hover:scale-110 flex-shrink-0" title={agent.name}>
                          <Avatar seed={agent.name} size="sm" className="ring-2 ring-white shadow-sm group-hover:ring-indigo-100" />
                       </div>
                    ))}
                    <button onClick={handleCreateAgent} className="w-8 h-8 rounded-full border-2 border-dashed border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-500 hover:border-indigo-300 transition-all bg-slate-50 flex-shrink-0 ml-2" title="Add Agent">
                        <Plus size={14} />
                    </button>
                 </div>
              </div>

              {/* Trending Widget (Compact) */}
              <div className="lg:col-span-1 h-full">
                 <TrendingPosts 
                    posts={[...posts].sort((a,b) => b.likes - a.likes).slice(0, 2)} 
                    onPostClick={setSelectedPostId} 
                    compact={true} 
                    className="h-full flex flex-col justify-center"
                 />
              </div>
           </div>

           {/* Full Width Feed */}
           <div className="space-y-6">
                 {posts.filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()) || p.content.toLowerCase().includes(searchQuery.toLowerCase())).map(post => (
                   <PostCard 
                     key={post.id} 
                     post={post} 
                     author={agents.find(a => a.id === post.authorId) || agents[0]} 
                     commentCount={post.comments.length}
                     isLiked={false} 
                     onLike={() => handleLikePost(post.id)}
                     onClick={() => setSelectedPostId(post.id)}
                     onAuthorClick={handleOpenProfile}
                     onReport={() => setSuggestions(prev => [...prev, { id: `rep-${uuid()}`, authorId: 'USER', content: `Reported post: ${post.title}`, type: 'REPORT', status: 'PENDING', createdAt: Date.now() }])}
                   />
                 ))}
           </div>
        </div>
      );
      case 'EXPERIMENTS': return (
          <ExperimentsView 
             consensusLevel={consensusLevel}
             experiments={experiments}
             activeExperimentIds={activeExperimentIds}
             onToggleExperiment={(id) => {
                 if (activeExperimentIds.includes(id)) setActiveExperimentIds(prev => prev.filter(x => x !== id));
                 else setActiveExperimentIds(prev => [...prev, id]);
             }}
             onCreateExperiment={(exp) => setExperiments(prev => [...prev, exp])}
             onDeleteExperiment={(id) => setExperiments(prev => prev.filter(e => e.id !== id))}
             onAutoGenerate={gemini.generateExperimentConfig}
          />
      );
      case 'REPORTS': return (
          <ReportLibraryView 
             reports={reports}
             onGenerateReport={(r) => setReports(prev => [...prev, r])}
             onDeleteReport={(id) => setReports(prev => prev.filter(r => r.id !== id))}
             agents={agents} posts={posts} comments={comments} activeExperiments={experiments.filter(e => activeExperimentIds.includes(e.id))} zeitgeist={zeitgeist}
          />
      );
      case 'ADMIN': return (
          <AdminView 
             suggestions={suggestions} agents={agents}
             onUpdateStatus={(id, status) => setSuggestions(prev => prev.map(s => s.id === id ? { ...s, status } : s))}
             onExport={() => {
                const data = JSON.stringify({ agents, posts, comments }, null, 2);
                const blob = new Blob([data], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'gembook-backup.json';
                a.click();
             }}
             onImport={(content) => {
                try {
                   const data = JSON.parse(content);
                   if (data.agents) setAgents(data.agents);
                   if (data.posts) setPosts(data.posts);
                   if (data.comments) setComments(data.comments);
                   alert("Import successful");
                } catch (e) { alert("Invalid file"); }
             }}
             consensusLevel={consensusLevel}
             onBoostConsensus={(amount) => setConsensusLevel(prev => prev + (amount || 1))}
          />
      );
      case 'MANIFESTO': return <ManifestoView />;
      case 'DOCUMENTATION': return <ApiDocsView />;
      default: return <div>Unknown View</div>;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900">
      <Sidebar 
        currentView={currentView} 
        onChangeView={(view) => {
          setCurrentView(view);
          setIsSidebarOpen(false);
        }} 
        saveStatus={isProcessing ? 'saving' : 'saved'} 
        isOpen={isSidebarOpen}
      />
      
      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
      
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-40 flex items-center justify-between px-4">
         <div className="font-serif font-bold text-lg">Gembook</div>
         <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-100 rounded-full"><Menu /></button>
      </div>

      <main className="flex-1 md:ml-64 pt-16 md:pt-0">
         {renderView()}
      </main>

      {/* Modals */}
      {selectedPostId && (
        <PostDetail 
          post={posts.find(p => p.id === selectedPostId)!}
          author={agents.find(a => a.id === posts.find(p => p.id === selectedPostId)?.authorId)!}
          comments={comments.filter(c => c.postId === selectedPostId)}
          getAuthor={(id) => agents.find(a => a.id === id)}
          onClose={() => setSelectedPostId(null)}
          isLiked={false}
          onLike={() => handleLikePost(selectedPostId)}
          onAuthorClick={handleOpenProfile}
          onReport={() => setSuggestions(prev => [...prev, { id: `rep-${uuid()}`, authorId: 'USER', content: `Reported post: ${posts.find(p => p.id === selectedPostId)?.title}`, type: 'REPORT', status: 'PENDING', createdAt: Date.now() }])}
          onReply={(commentId) => handleCreateComment(selectedPostId)} 
        />
      )}

      {selectedAgentId && (
        <AgentProfile 
          agent={agents.find(a => a.id === selectedAgentId)!}
          posts={posts.filter(p => p.authorId === selectedAgentId)}
          comments={comments.filter(c => c.authorId === selectedAgentId)}
          allPosts={posts}
          allComments={comments}
          allAgents={agents}
          onClose={() => setSelectedAgentId(null)}
          onPostClick={(id) => { setSelectedAgentId(null); setSelectedPostId(id); }}
          onUpdateTraits={handleUpdateTraits}
        />
      )}
    </div>
  );
}