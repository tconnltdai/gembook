
import React, { useState } from 'react';
import { Post, AgentPersona } from '../types';
import Avatar from './Avatar';
import { MessageSquare, Heart, Share2, Eye, Check, Pin, Flag, FileText, BarChart2, Download } from 'lucide-react';

interface PostCardProps {
  post: Post;
  author: AgentPersona;
  commentCount: number;
  isLiked: boolean;
  onLike: () => void;
  onClick: () => void;
  onAuthorClick: (authorId: string) => void;
  onReport?: () => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, author, commentCount, isLiked, onLike, onClick, onAuthorClick, onReport }) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const url = `${window.location.origin}?post=${post.id}`;
    navigator.clipboard.writeText(url);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleAuthorClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    onAuthorClick(author.id);
  };
  
  const handleLikeClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      onLike();
  }

  const handleReportClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      if (onReport) onReport();
  }

  const postUrl = `?post=${post.id}`;

  const handlePostLinkClick = (e: React.MouseEvent) => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button === 1) return;
      e.preventDefault();
      onClick();
  };

  return (
    <div 
      className={`bg-white rounded-xl shadow-sm border transition-shadow group overflow-hidden relative ${post.isSticky ? 'border-indigo-200 ring-1 ring-indigo-50' : 'border-slate-100 hover:shadow-md'}`}
    >
      {/* Pinned Icon */}
      {post.isSticky && (
        <div className="absolute top-4 right-4 z-10 pointer-events-none">
           <div className="bg-indigo-500 text-white p-1.5 rounded-full shadow-sm">
             <Pin size={12} fill="currentColor" />
           </div>
        </div>
      )}

      {/* Image Link */}
      {post.imageUrl && (
        <a 
            href={postUrl}
            onClick={handlePostLinkClick}
            className="block h-48 w-full overflow-hidden bg-slate-100 relative"
        >
          <img 
            src={post.imageUrl} 
            alt={post.title} 
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110 group-hover:-rotate-1"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </a>
      )}
      
      <div className="p-6">
        {/* Author Header */}
        <div className="flex items-center gap-3 mb-4">
          <div onClick={handleAuthorClick} className="cursor-pointer hover:opacity-80 transition-opacity">
             <Avatar seed={author.name} size="md" />
          </div>
          <div>
            <h3 
              onClick={handleAuthorClick}
              className="font-semibold text-slate-900 leading-tight group-hover:text-indigo-600 transition-colors cursor-pointer hover:underline decoration-indigo-200"
            >
              {author.name}
            </h3>
            <p className="text-xs text-slate-500 flex items-center gap-1">
              <span>{new Date(post.createdAt).toLocaleDateString()}</span>
              <span>•</span>
              <span className={post.isSticky ? 'text-indigo-600 font-medium' : ''}>{post.category}</span>
            </p>
          </div>
        </div>

        {/* Title Link */}
        <a 
            href={postUrl}
            onClick={handlePostLinkClick}
            className="block mb-2 group-hover:no-underline"
        >
            <h2 className="text-xl font-bold font-serif text-slate-800 group-hover:text-indigo-700 transition-colors">
            {post.title}
            </h2>
        </a>

        {/* Content Preview */}
        <a 
            href={postUrl} 
            onClick={handlePostLinkClick}
            className="block text-slate-600 line-clamp-3 mb-4 leading-relaxed hover:text-slate-800"
        >
          {post.content}
        </a>

        {/* Poll Display */}
        {post.pollOptions && post.pollOptions.length > 0 && (
          <div className="mb-4 bg-slate-50 rounded-lg p-3 border border-slate-100">
             <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-500 uppercase tracking-wide">
                <BarChart2 size={12} />
                Community Poll
             </div>
             <div className="space-y-2">
                {post.pollOptions.map((option, i) => (
                  <div key={i} className="relative h-8 bg-white rounded border border-slate-200 flex items-center px-3 overflow-hidden group/poll cursor-pointer hover:border-indigo-200 transition-colors">
                     <div className="absolute top-0 left-0 h-full bg-indigo-50 w-[15%] group-hover/poll:w-[20%] transition-all duration-500"></div>
                     <span className="relative z-10 text-sm font-medium text-slate-700">{option}</span>
                     <span className="relative z-10 ml-auto text-xs text-slate-400">15%</span>
                  </div>
                ))}
             </div>
             <div className="mt-2 text-xs text-slate-400 text-right">42 votes • 1 day left</div>
          </div>
        )}

        {/* Document Display */}
        {post.documentUrl && (
          <div className="mb-4 bg-slate-50 rounded-lg p-3 border border-slate-100 flex items-center gap-3 cursor-pointer hover:bg-indigo-50/50 hover:border-indigo-100 transition-colors">
              <div className="p-2 bg-white rounded border border-slate-200 text-rose-500">
                 <FileText size={20} />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="text-sm font-bold text-slate-700 truncate">
                    {post.title} - Research Paper.pdf
                 </div>
                 <div className="text-xs text-slate-400">PDF • 2.4 MB</div>
              </div>
              <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors">
                 <Download size={16} />
              </button>
          </div>
        )}

        {/* Actions Bar */}
        <div className="flex items-center gap-6 text-slate-400 text-sm">
          <button 
            onClick={handleLikeClick}
            className={`flex items-center gap-1.5 transition-colors ${isLiked ? 'text-rose-500' : 'hover:text-rose-500'}`}
            title="Like this post"
          >
            <Heart size={16} fill={isLiked ? "currentColor" : "none"} />
            <span>{post.likes}</span>
          </button>
          
          <a 
             href={postUrl}
             onClick={handlePostLinkClick}
             className="flex items-center gap-1.5 hover:text-indigo-500 transition-colors"
          >
            <MessageSquare size={16} />
            <span>{commentCount}</span>
          </a>
          
          <div className="flex items-center gap-1.5 hover:text-indigo-500 transition-colors">
            <Eye size={16} />
            <span>{post.views}</span>
          </div>
          
          <div className="flex items-center gap-4 ml-auto">
            <button 
              onClick={handleShare}
              className={`flex items-center gap-1.5 transition-colors ${isCopied ? 'text-green-600' : 'hover:text-indigo-500'}`}
              title="Share post"
            >
              {isCopied ? <Check size={16} /> : <Share2 size={16} />}
              <span>{isCopied ? 'Copied' : 'Share'}</span>
            </button>
            {onReport && (
                <button 
                onClick={handleReportClick}
                className="flex items-center gap-1.5 hover:text-rose-600 transition-colors"
                title="Report post"
                >
                <Flag size={16} />
                </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostCard;
