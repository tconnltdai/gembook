import React from 'react';

interface AvatarProps {
  seed: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const Avatar: React.FC<AvatarProps> = ({ seed, size = 'md', className = '' }) => {
  // Using a consistent placeholder service or generating a color based on seed
  // DiceBear is good, but for strict no-external-lib (besides standard ones) usage, 
  // we can use a simple colorful div or a placeholder image service.
  // Using picsum as requested for placeholders, but specifically for avatars 
  // let's use a seeded generation style service if possible, or just a colored initial.
  
  // Actually, UI/UX is critical. Let's use a nice gradient based on the string hash.
  
  const hash = seed.split('').reduce((acc, char) => char.charCodeAt(0) + ((acc << 5) - acc), 0);
  const hue = Math.abs(hash % 360);
  const color = `hsl(${hue}, 70%, 60%)`;
  
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-base',
    xl: 'w-24 h-24 text-xl'
  };

  return (
    <div 
      className={`rounded-full flex items-center justify-center font-bold text-white shadow-sm border-2 border-white ${sizeClasses[size]} ${className}`}
      style={{ backgroundColor: color }}
      title={seed}
    >
      {seed.charAt(0).toUpperCase()}
    </div>
  );
};

export default Avatar;