
import React, { useState } from 'react';
import { Report, AgentPersona, Post, Comment, Experiment, Zeitgeist } from '../types';
import { generateAnalysisReport } from '../services/geminiService';
import { Library, Plus, FileText, Calendar, ChevronRight, Loader2, Microscope, Bookmark, X } from 'lucide-react';

interface ReportLibraryViewProps {
  reports: Report[];
  onGenerateReport: (report: Report) => void;
  onDeleteReport: (id: string) => void;
  agents: AgentPersona[];
  posts: Post[];
  comments: Comment[];
  activeExperiments: Experiment[];
  zeitgeist: Zeitgeist | null;
}

const ReportLibraryView: React.FC<ReportLibraryViewProps> = ({ 
  reports, 
  onGenerateReport, 
  onDeleteReport,
  agents,
  posts,
  comments,
  activeExperiments,
  zeitgeist
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
        const data = await generateAnalysisReport(agents, posts, comments, activeExperiments, zeitgeist);
        const newReport: Report = {
            id: `REP-${Date.now()}`,
            date: Date.now(),
            ...data
        };
        onGenerateReport(newReport);
        setSelectedReport(newReport);
    } catch (e) {
        console.error("Failed to generate report", e);
        alert("Failed to generate report. Please try again.");
    } finally {
        setIsGenerating(false);
    }
  };

  const getTypeColor = (type: string) => {
      switch(type) {
          case 'EXPERIMENT_CONCLUSION': return 'bg-indigo-100 text-indigo-700 border-indigo-200';
          case 'ANOMALY_DETECTED': return 'bg-rose-100 text-rose-700 border-rose-200';
          default: return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header */}
      <div className="flex items-end justify-between mb-8 border-b border-slate-200 pb-6">
        <div>
           <h1 className="text-3xl font-serif font-bold text-slate-900 flex items-center gap-3">
             <Library className="text-indigo-500" strokeWidth={2.5} />
             Research Library
           </h1>
           <p className="text-slate-500 mt-2">
             Archived analysis of swarm behavior and experimental outcomes.
           </p>
        </div>
        <button 
          onClick={handleGenerate}
          disabled={isGenerating}
          className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 shadow-lg hover:shadow-xl transition-all disabled:opacity-70 disabled:cursor-not-allowed"
        >
          {isGenerating ? <Loader2 size={16} className="animate-spin" /> : <Microscope size={16} />}
          Generate Situation Report
        </button>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
          
          {/* List Column */}
          <div className="lg:col-span-4 space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Bookmark size={14} /> Archived Reports
              </h3>
              
              <div className="space-y-3">
                  {reports.length === 0 ? (
                      <div className="text-center py-12 bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 text-slate-400 text-sm">
                          No reports generated yet.
                      </div>
                  ) : (
                      reports.slice().reverse().map(report => (
                          <div 
                              key={report.id}
                              onClick={() => setSelectedReport(report)}
                              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                                  selectedReport?.id === report.id 
                                  ? 'bg-white border-indigo-500 ring-1 ring-indigo-500 shadow-md' 
                                  : 'bg-white border-slate-200 hover:border-indigo-300 hover:shadow-sm'
                              }`}
                          >
                              <div className="flex justify-between items-start mb-2">
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${getTypeColor(report.type)}`}>
                                      {report.type.replace('_', ' ')}
                                  </span>
                                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                      <Calendar size={10} />
                                      {new Date(report.date).toLocaleDateString()}
                                  </span>
                              </div>
                              <h4 className="font-bold text-slate-800 text-sm leading-tight mb-1 line-clamp-2">
                                  {report.title}
                              </h4>
                          </div>
                      ))
                  )}
              </div>
          </div>

          {/* Preview Column */}
          <div className="lg:col-span-8">
              {selectedReport ? (
                  <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden min-h-[600px] flex flex-col">
                      <div className="p-8 border-b border-slate-100 bg-slate-50/50">
                          <div className="flex justify-between items-start mb-4">
                              <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${getTypeColor(selectedReport.type)}`}>
                                  <FileText size={12} /> {selectedReport.type.replace('_', ' ')}
                              </div>
                              <div className="flex items-center gap-2">
                                  <span className="text-xs font-mono text-slate-400">{selectedReport.id}</span>
                                  <button onClick={() => onDeleteReport(selectedReport.id)} className="text-slate-400 hover:text-rose-500 p-1">
                                      <X size={16} />
                                  </button>
                              </div>
                          </div>
                          <h2 className="text-2xl font-serif font-bold text-slate-900 leading-tight">
                              {selectedReport.title}
                          </h2>
                          <div className="text-sm text-slate-500 mt-2 flex items-center gap-2">
                              Generated on {new Date(selectedReport.date).toLocaleString()}
                          </div>
                      </div>
                      
                      <div className="p-8 flex-1">
                          <div className="mb-8">
                              <h4 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-3">Executive Summary</h4>
                              <div className="prose prose-slate prose-sm max-w-none text-slate-700 leading-relaxed whitespace-pre-wrap">
                                  {selectedReport.content}
                              </div>
                          </div>
                          
                          <div className="bg-indigo-50/50 rounded-xl p-6 border border-indigo-100">
                              <h4 className="text-sm font-bold text-indigo-900 uppercase tracking-wider mb-3 flex items-center gap-2">
                                  <Microscope size={16} /> Key Findings
                              </h4>
                              <ul className="space-y-2">
                                  {selectedReport.keyFindings.map((finding, i) => (
                                      <li key={i} className="flex gap-3 text-sm text-indigo-900/80">
                                          <span className="font-bold text-indigo-500 select-none">•</span>
                                          {finding}
                                      </li>
                                  ))}
                              </ul>
                          </div>
                      </div>
                  </div>
              ) : (
                  <div className="h-full flex flex-col items-center justify-center p-12 bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 text-slate-400">
                      <Library size={48} strokeWidth={1} className="mb-4 opacity-50" />
                      <p className="font-medium text-lg text-slate-500">Select a report to view details</p>
                      <p className="text-sm mt-2">or generate a new analysis of the current simulation.</p>
                  </div>
              )}
          </div>

      </div>
    </div>
  );
};

export default ReportLibraryView;
