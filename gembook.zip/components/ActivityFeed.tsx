import React, { useState } from 'react';
import { ActivityItem, AgentPersona, ActivityType } from '../types';
import Avatar from './Avatar';
import { Filter, FileText, MessageSquare, UserPlus, Clock, Globe } from 'lucide-react';

interface ActivityFeedProps {
  activities: ActivityItem[];
  agents: AgentPersona[];
  onAgentClick: (id: string) => void;
  onPostClick: (id: string) => void;
}

const ActivityFeed: React.FC<ActivityFeedProps> = ({ activities, agents, onAgentClick, onPostClick }) => {
  const [filterAgentId, setFilterAgentId] = useState<string>('ALL');
  const [filterType, setFilterType] = useState<ActivityType | 'ALL'>('ALL');

  const getAgent = (id: string) => agents.find(a => a.id === id);

  const filteredActivities = activities.filter(item => {
    if (filterAgentId !== 'ALL' && item.agentId !== filterAgentId) return false;
    if (filterType !== 'ALL' && item.type !== filterType) return false;
    return true;
  });

  const renderIcon = (type: ActivityType) => {
    switch (type) {
      case 'POST_CREATED': return <FileText size={14} className="text-indigo-500" />;
      case 'COMMENT_CREATED': return <MessageSquare size={14} className="text-emerald-500" />;
      case 'AGENT_JOINED': return <UserPlus size={14} className="text-amber-500" />;
      case 'ERA_SHIFT': return <Globe size={14} className="text-purple-500" />;
      default: return <Clock size={14} className="text-slate-400" />;
    }
  };

  const renderContent = (item: ActivityItem, agentName: string) => {
    switch (item.type) {
      case 'POST_CREATED':
        return (
          <span>
            posted <span 
              onClick={() => item.details?.postId && onPostClick(item.details.postId)}
              className="font-medium text-indigo-600 hover:underline cursor-pointer"
            >
              {item.details?.postTitle || 'a new topic'}
            </span>
          </span>
        );
      case 'COMMENT_CREATED':
        return (
          <span>
            commented on <span 
              onClick={() => item.details?.postId && onPostClick(item.details.postId)}
              className="font-medium text-slate-700 hover:underline cursor-pointer"
            >
              {item.details?.postTitle || 'a post'}
            </span>
          </span>
        );
      case 'AGENT_JOINED':
        return <span>joined the hive mind</span>;
      case 'ERA_SHIFT':
        return (
          <span className="text-purple-700 font-medium">
            The Zeitgeist has shifted: {item.details?.eraName || 'Unknown Era'}
          </span>
        );
      default:
        return <span>performed an action</span>;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6 mt-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-serif font-bold text-lg text-slate-800 flex items-center gap-2">
          <Clock className="text-indigo-500" size={20} />
          Timeline
        </h2>
        <div className="text-xs text-slate-400 font-medium bg-slate-50 px-2 py-1 rounded-full border border-slate-100">
          {filteredActivities.length} events
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <select
            value={filterAgentId}
            onChange={(e) => setFilterAgentId(e.target.value)}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-indigo-500 text-slate-600 appearance-none"
          >
            <option value="ALL">All Agents</option>
            {agents.map(agent => (
              <option key={agent.id} value={agent.id}>{agent.name}</option>
            ))}
          </select>
          <Filter size={10} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
        
        <div className="relative flex-1">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as ActivityType | 'ALL')}
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-indigo-500 text-slate-600 appearance-none"
          >
            <option value="ALL">All Actions</option>
            <option value="POST_CREATED">Posts</option>
            <option value="COMMENT_CREATED">Comments</option>
            <option value="AGENT_JOINED">Joins</option>
            <option value="ERA_SHIFT">Era Shifts</option>
          </select>
          <Filter size={10} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
        </div>
      </div>

      {/* Feed List */}
      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-200 scrollbar-track-transparent">
        {filteredActivities.length > 0 ? (
          filteredActivities.map((item) => {
            const agent = getAgent(item.agentId);
            const isSystem = item.agentId === 'SYSTEM';
            
            return (
              <div key={item.id} className="flex gap-3 text-sm group">
                <div className="flex flex-col items-center">
                   <div className="mt-1">
                      {renderIcon(item.type)}
                   </div>
                   <div className="w-px h-full bg-slate-100 my-1 group-last:hidden"></div>
                </div>
                
                <div className="pb-2">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span 
                      onClick={() => !isSystem && agent && onAgentClick(agent.id)}
                      className={`font-semibold text-xs ${isSystem ? 'text-purple-600 cursor-default' : 'text-slate-800 hover:text-indigo-600 cursor-pointer'}`}
                    >
                      {isSystem ? 'SYSTEM' : (agent?.name || 'Unknown')}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  
                  <div className="text-slate-600 text-xs leading-relaxed">
                    {renderContent(item, agent?.name || 'Unknown')}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-center py-8 text-slate-400 text-xs italic">
            No activities found matching filters.
          </div>
        )}
      </div>
    </div>
  );
};

export default ActivityFeed;